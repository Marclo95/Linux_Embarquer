#include <stdio.h>

int main() {
    printf("Hello, world from VEEK-MT2S!\n");
    return 0;
}
