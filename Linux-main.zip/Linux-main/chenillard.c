#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

#define NUM_LEDS 10  // de fpga_led0 à fpga_led9
#define LED_PATH_FORMAT "/sys/class/leds/fpga_led%d/brightness"

void set_led(int led_num, int value) {
    char path[128];
    snprintf(path, sizeof(path), LED_PATH_FORMAT, led_num);

    int fd = open(path, O_WRONLY);
    if (fd < 0) {
        perror("Erreur lors de l'ouverture du fichier LED");
        return;
    }

    char buffer[2];
    snprintf(buffer, sizeof(buffer), "%d", value);
    if (write(fd, buffer, strlen(buffer)) < 0) {
        perror("Erreur d'écriture dans le fichier LED");
    }

    close(fd);
}

int main() {
    while (1) {
        for (int i = 0; i < NUM_LEDS; i++) {
            // Éteindre toutes les LEDs
            for (int j = 0; j < NUM_LEDS; j++) {
                set_led(j, 0);
            }

            // Allumer la LED à la position i
            set_led(i, 1);
            usleep(200000);  // 200 ms
        }
    }

    return 0;
}
