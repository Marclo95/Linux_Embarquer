#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/uaccess.h>      // copy_to_user / copy_from_user
#include <linux/proc_fs.h>      // proc_create, remove_proc_entry
#include <linux/seq_file.h>     
#include <linux/slab.h>         

#define DRIVER_AUTHOR "Christophe Barès"
#define DRIVER_DESC "Hello world Module"
#define DRIVER_LICENSE "GPL"

#define TAILLE 256
static char message[TAILLE] = "Message par défaut\n";

static int param = 3;
static struct file_operations proc_fops;
static struct proc_dir_entry *dir_ensea;

// Permet de passer un paramètre au module
module_param(param, int, 0);
MODULE_PARM_DESC(param, "Un paramètre de ce module");

// Fonction de lecture depuis /proc
ssize_t fops_read(struct file *file, char __user *buffer, size_t count, loff_t *ppos) {
    int len = strlen(message);

    if (*ppos > 0 || count < len)
        return 0;

    if (copy_to_user(buffer, message, len))
        return -EFAULT;

    *ppos = len;
    printk(KERN_INFO "message read: %s", message);
    return len;
}

// Fonction d’écriture vers /proc
ssize_t fops_write(struct file *file, const char __user *buffer, size_t count, loff_t *ppos) {
    int len = (count < TAILLE - 1) ? count : TAILLE - 1;

    if (copy_from_user(message, buffer, len))
        return -EFAULT;

    message[len] = '\0'; // termine la chaîne
    printk(KERN_INFO "nouveau message écrit : %s", message);
    return count;
}

static int __init hello_init(void) {
    printk(KERN_INFO "Hello world!\n");
    printk(KERN_INFO "Paramètre = %d\n", param);

    proc_fops.read = fops_read;
    proc_fops.write = fops_write;

    // Créer un dossier /proc/ensea
    dir_ensea = proc_mkdir("ensea", NULL);
    if (!dir_ensea) {
        printk(KERN_ERR "Erreur création /proc/ensea\n");
        return -ENOMEM;
    }

    // Créer un fichier /proc/ensea/test
    if (!proc_create("test", 0666, dir_ensea, &proc_fops)) {
        remove_proc_entry("ensea", NULL);
        printk(KERN_ERR "Erreur création /proc/ensea/test\n");
        return -ENOMEM;
    }

    return 0;
}

static void __exit hello_exit(void) {
    remove_proc_entry("test", dir_ensea);
    remove_proc_entry("ensea", NULL);
    printk(KERN_INFO "Bye bye...\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE(DRIVER_LICENSE);
MODULE_AUTHOR(DRIVER_AUTHOR);
MODULE_DESCRIPTION(DRIVER_DESC);
